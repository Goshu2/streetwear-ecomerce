"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { X, ChevronRight } from "lucide-react"

import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { SheetClose, SheetHeader, SheetTitle } from "@/components/ui/sheet"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"

interface MobileNavProps {
  navItems: { label: string; href: string }[]
  categories?: any[]
}

export default function MobileNav({ navItems, categories = [] }: MobileNavProps) {
  const pathname = usePathname()

  return (
    <div className="flex h-full flex-col">
      <SheetHeader className="border-b px-4 py-4">
        <div className="flex items-center justify-between">
          <SheetTitle>Menu</SheetTitle>
          <SheetClose asChild>
            <Button variant="ghost" size="icon">
              <X className="h-5 w-5" />
              <span className="sr-only">Close</span>
            </Button>
          </SheetClose>
        </div>
      </SheetHeader>
      <ScrollArea className="flex-1">
        <nav className="flex flex-col gap-4 p-4">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={`text-lg font-medium transition-colors hover:text-primary ${
                pathname === item.href ? "text-primary" : "text-foreground/60"
              }`}
            >
              {item.label}
            </Link>
          ))}

          <Accordion type="single" collapsible className="w-full">
            <AccordionItem value="categories" className="border-none">
              <AccordionTrigger className="text-lg font-medium py-2">Categories</AccordionTrigger>
              <AccordionContent>
                <div className="flex flex-col space-y-2 pl-4">
                  {categories.length === 0 ? (
                    <p className="text-sm text-muted-foreground">No categories found</p>
                  ) : (
                    categories.map((category) => (
                      <Link
                        key={category.id}
                        href={`/category/${category.slug}`}
                        className="flex items-center justify-between text-foreground/60 hover:text-primary py-1"
                      >
                        <span>{category.name}</span>
                        <ChevronRight className="h-4 w-4" />
                      </Link>
                    ))
                  )}
                  <Link href="/categories" className="flex items-center justify-between text-primary font-medium py-1">
                    <span>View All Categories</span>
                    <ChevronRight className="h-4 w-4" />
                  </Link>
                </div>
              </AccordionContent>
            </AccordionItem>
          </Accordion>

          <Link
            href="/about"
            className={`text-lg font-medium transition-colors hover:text-primary ${
              pathname === "/about" ? "text-primary" : "text-foreground/60"
            }`}
          >
            About
          </Link>

          <Link
            href="/contact"
            className={`text-lg font-medium transition-colors hover:text-primary ${
              pathname === "/contact" ? "text-primary" : "text-foreground/60"
            }`}
          >
            Contact
          </Link>
        </nav>
      </ScrollArea>
    </div>
  )
}
