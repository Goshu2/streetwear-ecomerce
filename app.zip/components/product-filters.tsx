"use client"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { Filter, X } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Slider } from "@/components/ui/slider"
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetFooter,
  SheetHeader,
  SheetTitle,
  SheetTrigger,
} from "@/components/ui/sheet"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { getBrands } from "@/lib/firebase/brands"
import { getCategories } from "@/lib/firebase/categories"

export default function ProductFilters() {
  const router = useRouter()
  const searchParams = useSearchParams()
  const [isOpen, setIsOpen] = useState(false)
  const [priceRange, setPriceRange] = useState([0, 1000])
  const [selectedCategories, setSelectedCategories] = useState([])
  const [selectedBrands, setSelectedBrands] = useState([])
  const [selectedColors, setSelectedColors] = useState([])
  const [selectedSizes, setSelectedSizes] = useState([])
  const [categories, setCategories] = useState([])
  const [brands, setBrands] = useState([])
  const [loading, setLoading] = useState(true)
  const [activeFilters, setActiveFilters] = useState([])

  // Common colors and sizes
  const colors = ["Black", "White", "Gray", "Red", "Blue", "Green", "Yellow", "Purple", "Pink", "Brown"]
  const sizes = ["XS", "S", "M", "L", "XL", "XXL", "3XL"]

  // Load initial filter values from URL params
  useEffect(() => {
    const minPrice = searchParams.get("minPrice") ? Number.parseInt(searchParams.get("minPrice")) : 0
    const maxPrice = searchParams.get("maxPrice") ? Number.parseInt(searchParams.get("maxPrice")) : 1000
    const categoryIds = searchParams.get("categories") ? searchParams.get("categories").split(",") : []
    const brandIds = searchParams.get("brands") ? searchParams.get("brands").split(",") : []
    const colorValues = searchParams.get("colors") ? searchParams.get("colors").split(",") : []
    const sizeValues = searchParams.get("sizes") ? searchParams.get("sizes").split(",") : []

    setPriceRange([minPrice, maxPrice])
    setSelectedCategories(categoryIds)
    setSelectedBrands(brandIds)
    setSelectedColors(colorValues)
    setSelectedSizes(sizeValues)

    // Update active filters display
    updateActiveFilters([minPrice, maxPrice], categoryIds, brandIds, colorValues, sizeValues)
  }, [searchParams])

  // Fetch categories and brands on component mount
  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true)
        const [fetchedCategories, fetchedBrands] = await Promise.all([getCategories(), getBrands()])
        setCategories(fetchedCategories)
        setBrands(fetchedBrands)
      } catch (error) {
        console.error("Error fetching filter data:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  const updateActiveFilters = (priceRange, categoryIds, brandIds, colorValues, sizeValues) => {
    const filters = []

    // Add price filter if not default
    if (priceRange[0] > 0 || priceRange[1] < 1000) {
      filters.push({
        type: "price",
        label: `$${priceRange[0]} - $${priceRange[1]}`,
      })
    }

    // Add category filters
    categoryIds.forEach((id) => {
      const category = categories.find((c) => c.id === id)
      if (category) {
        filters.push({
          type: "category",
          id: category.id,
          label: category.name,
        })
      }
    })

    // Add brand filters
    brandIds.forEach((brandName) => {
      // Instead of matching by id, we now search by brand name in the brands array
      const brand = brands.find((b) => b.name === brandName)
      if (brand) {
        filters.push({
          type: "brand",
          id: brand.name,
          label: brand.name,
        })
      }
    })

    // Add color filters
    colorValues.forEach((color) => {
      filters.push({
        type: "color",
        id: color,
        label: color,
      })
    })

    // Add size filters
    sizeValues.forEach((size) => {
      filters.push({
        type: "size",
        id: size,
        label: size,
      })
    })

    setActiveFilters(filters)
  }

  const handlePriceChange = (value) => {
    setPriceRange(value)
  }

  const toggleCategory = (categoryId) => {
    setSelectedCategories((prev) =>
      prev.includes(categoryId) ? prev.filter((id) => id !== categoryId) : [...prev, categoryId],
    )
  }

  const toggleBrand = (brandValue) => {
    setSelectedBrands((prev) =>
      prev.includes(brandValue) ? prev.filter((b) => b !== brandValue) : [...prev, brandValue]
    )
  }

  const toggleColor = (color) => {
    setSelectedColors((prev) => (prev.includes(color) ? prev.filter((c) => c !== color) : [...prev, color]))
  }

  const toggleSize = (size) => {
    setSelectedSizes((prev) => (prev.includes(size) ? prev.filter((s) => s !== size) : [...prev, size]))
  }

  const applyFilters = () => {
    // Create a new URLSearchParams object
    const params = new URLSearchParams()

    // Add price range if not default
    if (priceRange[0] > 0) {
      params.set("minPrice", priceRange[0].toString())
    }
    if (priceRange[1] < 1000) {
      params.set("maxPrice", priceRange[1].toString())
    }

    // Add categories if selected
    if (selectedCategories.length > 0) {
      params.set("categories", selectedCategories.join(","))
    }

    // Add brands if selected
    if (selectedBrands.length > 0) {
      params.set("brands", selectedBrands.join(","))
    }

    // Add colors if selected
    if (selectedColors.length > 0) {
      params.set("colors", selectedColors.join(","))
    }

    // Add sizes if selected
    if (selectedSizes.length > 0) {
      params.set("sizes", selectedSizes.join(","))
    }

    // Preserve search term if it exists
    const search = searchParams.get("search")
    if (search) {
      params.set("search", search)
    }

    // Update the URL with the new params
    const queryString = params.toString()
    router.push(`/products${queryString ? `?${queryString}` : ""}`)

    // Close the filter sheet
    setIsOpen(false)

    // Update active filters display
    updateActiveFilters(priceRange, selectedCategories, selectedBrands, selectedColors, selectedSizes)
  }

  const clearFilters = () => {
    setPriceRange([0, 1000])
    setSelectedCategories([])
    setSelectedBrands([])
    setSelectedColors([])
    setSelectedSizes([])
  }

  const removeFilter = (filter) => {
    switch (filter.type) {
      case "price":
        setPriceRange([0, 1000])
        break
      case "category":
        setSelectedCategories((prev) => prev.filter((id) => id !== filter.id))
        break
      case "brand":
        setSelectedBrands((prev) => prev.filter((id) => id !== filter.id))
        break
      case "color":
        setSelectedColors((prev) => prev.filter((color) => color !== filter.id))
        break
      case "size":
        setSelectedSizes((prev) => prev.filter((size) => size !== filter.id))
        break
    }

    // Apply filters immediately after removing one
    setTimeout(() => applyFilters(), 0)
  }

  const activeFilterCount = activeFilters.length

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2">
        <Sheet open={isOpen} onOpenChange={setIsOpen}>
          <SheetTrigger asChild>
            <Button variant="outline" size="sm" className="h-8 border-dashed">
              <Filter className="mr-2 h-4 w-4" />
              Filter Products
              {activeFilterCount > 0 && (
                <span className="ml-1 rounded-full bg-primary w-5 h-5 text-xs flex items-center justify-center text-primary-foreground">
                  {activeFilterCount}
                </span>
              )}
            </Button>
          </SheetTrigger>
          <SheetContent className="w-[300px] sm:w-[400px] overflow-y-auto">
            <SheetHeader>
              <SheetTitle>Filter Products</SheetTitle>
              <SheetDescription>Narrow down products by applying filters</SheetDescription>
            </SheetHeader>
            <div className="py-6 space-y-6">
              <div className="space-y-4">
                <h3 className="text-sm font-medium">Price Range</h3>
                <div className="px-2">
                  <Slider
                    defaultValue={priceRange}
                    min={0}
                    max={1000}
                    step={10}
                    value={priceRange}
                    onValueChange={handlePriceChange}
                  />
                  <div className="flex items-center justify-between mt-2">
                    <span className="text-sm">${priceRange[0]}</span>
                    <span className="text-sm">${priceRange[1]}</span>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-sm font-medium">Categories</h3>
                {loading ? (
                  <div className="text-sm text-muted-foreground">Loading categories...</div>
                ) : categories.length === 0 ? (
                  <div className="text-sm text-muted-foreground">No categories available</div>
                ) : (
                  <div className="grid grid-cols-1 gap-2">
                    {categories.map((category) => (
                      <div key={category.id} className="flex items-center space-x-2">
                        <Checkbox
                          id={`category-${category.id}`}
                          checked={selectedCategories.includes(category.id)}
                          onCheckedChange={() => toggleCategory(category.id)}
                        />
                        <Label htmlFor={`category-${category.id}`} className="text-sm font-normal">
                          {category.name}
                        </Label>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="space-y-4">
                <h3 className="text-sm font-medium">Brands</h3>
                {loading ? (
                  <div className="text-sm text-muted-foreground">Loading brands...</div>
                ) : brands.length === 0 ? (
                  <div className="text-sm text-muted-foreground">No brands available</div>
                ) : (
                  <div className="grid grid-cols-1 gap-2">
                    {brands.map((brand) => (
                      <div key={brand.id} className="flex items-center space-x-2">
                        <Checkbox
                          id={`brand-${brand.id}`}
                          checked={selectedBrands.includes(brand.name)}
                          onCheckedChange={() => toggleBrand(brand.name)}
                        />
                        <Label htmlFor={`brand-${brand.id}`} className="text-sm font-normal">
                          {brand.name}
                        </Label>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <div className="space-y-4">
                <h3 className="text-sm font-medium">Colors</h3>
                <div className="grid grid-cols-2 gap-2">
                  {colors.map((color) => (
                    <div key={color} className="flex items-center space-x-2">
                      <Checkbox
                        id={`color-${color}`}
                        checked={selectedColors.includes(color)}
                        onCheckedChange={() => toggleColor(color)}
                      />
                      <Label htmlFor={`color-${color}`} className="text-sm font-normal">
                        {color}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-sm font-medium">Sizes</h3>
                <div className="grid grid-cols-3 gap-2">
                  {sizes.map((size) => (
                    <div key={size} className="flex items-center space-x-2">
                      <Checkbox
                        id={`size-${size}`}
                        checked={selectedSizes.includes(size)}
                        onCheckedChange={() => toggleSize(size)}
                      />
                      <Label htmlFor={`size-${size}`} className="text-sm font-normal">
                        {size}
                      </Label>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <SheetFooter className="flex-col sm:flex-row gap-2 sm:gap-0">
              <Button variant="outline" onClick={clearFilters} className="w-full sm:w-auto">
                <X className="mr-2 h-4 w-4" />
                Clear Filters
              </Button>
              <Button onClick={applyFilters} className="w-full sm:w-auto">
                Apply Filters
              </Button>
            </SheetFooter>
          </SheetContent>
        </Sheet>
      </div>

      {/* Active filters display */}
      {activeFilterCount > 0 && (
        <div className="flex flex-wrap gap-2 mt-2">
          {activeFilters.map((filter, index) => (
            <Badge
              key={`${filter.type}-${filter.id || index}`}
              variant="secondary"
              className="flex items-center gap-1 px-2 py-1"
            >
              {filter.label}
              <X className="h-3 w-3 cursor-pointer" onClick={() => removeFilter(filter)} />
            </Badge>
          ))}
          {activeFilterCount > 0 && (
            <Badge
              variant="outline"
              className="flex items-center gap-1 px-2 py-1 cursor-pointer"
              onClick={() => {
                clearFilters()
                router.push("/products")
              }}
            >
              Clear all
              <X className="h-3 w-3" />
            </Badge>
          )}
        </div>
      )}
    </div>
  )
}
