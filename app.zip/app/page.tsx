import Link from "next/link"
import { ArrowRight } from "lucide-react"

import { Button } from "@/components/ui/button"
import ProductCard from "@/components/product-card"
import FeaturedCollection from "@/components/featured-collection"
import { getProducts } from "@/lib/firebase/products"
import { getCategories } from "@/lib/firebase/categories"

// Convert Firestore Timestamps to plain number (milliseconds) or string
function toPlainTimestamp(timestamp: any) {
  // Safety checks in case `timestamp` is undefined or not a Firestore Timestamp
  if (!timestamp || typeof timestamp.toMillis !== "function") {
    return null
  }
  return timestamp.toMillis()
}

export default async function Home() {
  // Fetch featured products for the trending section
  const productsRaw = await getProducts({
    limitCount: 4,
    sortBy: "rating",
    sortDirection: "desc",
  })

  // Convert each product's Firestore fields to plain objects/values:
  // Convert both createdAt and updatedAt fields.
  const trendingProducts = productsRaw.map((p) => {
    return {
      ...p,
      createdAt: toPlainTimestamp(p.createdAt),
      updatedAt: toPlainTimestamp(p.updatedAt),
    }
  })

  // Fetch all categories for the featured categories section
  const categoriesRaw = await getCategories()
  const categories = categoriesRaw.map((c) => {
    return {
      ...c,
      createdAt: toPlainTimestamp(c.createdAt),
    }
  })

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="w-full py-12 md:py-24 lg:py-32 bg-black text-white">
        <div className="container px-4 md:px-6">
          <div className="grid gap-6 lg:grid-cols-2 lg:gap-12 items-center">
            <div className="flex flex-col justify-center space-y-4">
              <div className="space-y-2">
                <h1 className="text-3xl font-bold tracking-tighter sm:text-5xl xl:text-6xl/none">ELEVATE YOUR STYLE</h1>
                <p className="max-w-[600px] text-gray-300 md:text-xl">
                  Discover the latest streetwear trends and exclusive drops from top brands.
                </p>
              </div>
              <div className="flex flex-col gap-2 min-[400px]:flex-row">
                <Link href="/products">
                  <Button size="lg" className="bg-white text-black hover:bg-gray-200">
                    Shop Now
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
                <Link href="/products?sortBy=createdAt&sortDirection=desc">
                  <Button size="lg" variant="outline" className="border-white text-white hover:bg-white/10">
                    New Arrivals
                  </Button>
                </Link>
              </div>
            </div>
            <div className="flex justify-center lg:justify-end">
              <div className="relative w-full max-w-[500px] aspect-square overflow-hidden rounded-xl">
                <img
                  src="/placeholder.svg?height=600&width=600"
                  alt="Latest streetwear collection"
                  className="object-cover w-full h-full"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured Categories */}
      <section className="w-full py-12 md:py-24 bg-white">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Shop by Category</h2>
              <p className="max-w-[700px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                Explore our curated collections of premium streetwear
              </p>
            </div>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-8 mt-8">
            {categories.slice(0, 4).map((category) => (
              <Link key={category.id} href={`/category/${category.slug}`}>
                <div className="group relative overflow-hidden rounded-lg">
                  <div className="aspect-square w-full overflow-hidden rounded-lg bg-gray-100">
                    <img
                      src={`/placeholder.svg?height=400&width=400&text=${category.name}`}
                      alt={category.name}
                      className="object-cover w-full h-full transition-transform group-hover:scale-105"
                    />
                  </div>
                  <div className="absolute inset-0 flex items-end bg-gradient-to-t from-black/60 to-transparent p-4">
                    <h3 className="text-xl font-medium text-white">{category.name}</h3>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Trending Products */}
      <section className="w-full py-12 md:py-24 bg-gray-50">
        <div className="container px-4 md:px-6">
          <div className="flex flex-col items-center justify-center space-y-4 text-center">
            <div className="space-y-2">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">Trending Now</h2>
              <p className="max-w-[700px] text-gray-500 md:text-xl/relaxed lg:text-base/relaxed xl:text-xl/relaxed">
                The most popular items this season
              </p>
            </div>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6 mt-8">
            {trendingProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
          <div className="flex justify-center mt-10">
            <Link href="/products">
              <Button size="lg">
                View All Products
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Featured Collection */}
      <FeaturedCollection />
    </div>
  )
}
