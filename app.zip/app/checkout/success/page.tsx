import Link from "next/link"
import { Check, ShoppingBag } from "lucide-react"
import { Button } from "@/components/ui/button"

export default function CheckoutSuccessPage() {
  // In a complete implementation, you would fetch the order details
  // from the database using a server action or API route

  return (
    <div className="container px-4 md:px-6 py-8 md:py-12">
      <div className="mx-auto max-w-md text-center">
        <div className="flex justify-center mb-6">
          <div className="rounded-full bg-green-100 p-3">
            <Check className="h-8 w-8 text-green-600" />
          </div>
        </div>

        <h1 className="text-3xl font-bold mb-2">Order Confirmed!</h1>
        <p className="text-gray-500 mb-6">
          Thank you for your purchase. Your order has been confirmed and will be shipped soon.
        </p>

        <div className="rounded-lg border p-6 mb-6 text-left">
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="font-medium">Order Number:</span>
              <span>#{getRandomOrderNumber()}</span>
            </div>
            <div className="flex justify-between">
              <span className="font-medium">Date:</span>
              <span>{new Date().toLocaleDateString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="font-medium">Email:</span>
              <span>Your email has been sent a confirmation</span>
            </div>
            <div className="flex justify-between">
              <span className="font-medium">Payment Method:</span>
              <span>Credit Card</span>
            </div>
          </div>
        </div>

        <p className="text-sm text-gray-500 mb-6">
          A confirmation email has been sent with all the details of your order.
        </p>

        <div className="flex flex-col space-y-3">
          <Link href="/account/orders">
            <Button variant="outline" className="w-full">
              View Order Details
            </Button>
          </Link>
          <Link href="/products">
            <Button className="w-full">
              <ShoppingBag className="mr-2 h-4 w-4" />
              Continue Shopping
            </Button>
          </Link>
        </div>
      </div>
    </div>
  )
}

// Helper function to generate a random order number for display
function getRandomOrderNumber() {
  return `ORD-${Math.floor(100000 + Math.random() * 900000)}`
}
